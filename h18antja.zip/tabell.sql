-- SQLite
create table products (
    name VARCHAR(64) UNIQUE,
    description VARCHAR(64),
    price INT(12),
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL);

INSERT INTO products(name, description, price)
    VALUES 
    ('Nocco','dricka','25' ),
    ('bonaqua','dricka','19');


CREATE TABLE users (
    email VARCHAR(64) UNIQUE,
    firstname VARSCHAR(32),
    lastname VARCHAR(32),
    password VARCHAR(255),
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL);

INSERT INTO users(email, firstname,lastname,password)
    VALUES
    ('hejsvejs@gmail.com','Anton','Jansson','123hej'),
    ('1232gmail.com','Johanna', 'korv','pajen');